"""
TASK 1: Web Scraping
Project: Book Catalogue Dataset
Target: https://books.toscrape.com/ (a practice website made for web-scraping exercises)

Run:
    pip install -r requirements.txt
    python scraper.py

Output:
    books_dataset.csv
"""
import csv
import time
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup

START_URL = "https://books.toscrape.com/"
OUTPUT_FILE = "books_dataset.csv"
HEADERS = {
    "User-Agent": "EducationalBookCatalogueScraper/1.0 (learning project)"
}
FIELDS = [
    "title", "price_gbp", "availability", "rating",
    "product_url", "category", "upc", "stock_count"
]

def clean_text(element):
    return element.get_text(" ", strip=True) if element else ""

def get_soup(session, url):
    response = session.get(url, headers=HEADERS, timeout=20)
    response.raise_for_status()
    return BeautifulSoup(response.content, "html.parser")

def scrape_book_detail(session, url):
    """Collect extra fields from an individual book page."""
    try:
        soup = get_soup(session, url)
        details = {}
        for row in soup.select("table.table tr"):
            key = clean_text(row.select_one("th"))
            value = clean_text(row.select_one("td"))
            if key:
                details[key.lower().replace(" ", "_")] = value

        category_link = soup.select_one("ul.breadcrumb li:nth-of-type(3) a")
        stock_text = clean_text(soup.select_one(".instock.availability"))
        stock_digits = "".join(ch for ch in stock_text if ch.isdigit())

        return {
            "category": clean_text(category_link),
            "upc": details.get("upc", ""),
            "stock_count": stock_digits,
        }
    except requests.RequestException as exc:
        print(f"  Warning: could not read detail page {url}: {exc}")
        return {"category": "", "upc": "", "stock_count": ""}

def scrape_catalogue():
    rows = []
    seen_urls = set()
    current_url = START_URL

    with requests.Session() as session:
        page_number = 1
        while current_url:
            print(f"Scraping catalogue page {page_number}: {current_url}")
            try:
                soup = get_soup(session, current_url)
            except requests.RequestException as exc:
                print(f"Could not retrieve page: {exc}")
                break

            cards = soup.select("article.product_pod")
            if not cards:
                print("No book cards found. The site structure may have changed.")
                break

            for card in cards:
                title_link = card.select_one("h3 a")
                price_element = card.select_one(".price_color")
                availability_element = card.select_one(".availability")
                rating_element = card.select_one("p.star-rating")

                if not title_link:
                    continue

                product_url = urljoin(current_url, title_link.get("href", ""))
                if product_url in seen_urls:
                    continue
                seen_urls.add(product_url)

                rating_classes = rating_element.get("class", []) if rating_element else []
                rating = next(
                    (name for name in rating_classes
                     if name in {"One", "Two", "Three", "Four", "Five"}), ""
                )
                rating_map = {
                    "One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5
                }

                price_text = clean_text(price_element).replace("£", "").strip()
                detail = scrape_book_detail(session, product_url)

                rows.append({
                    "title": title_link.get("title") or clean_text(title_link),
                    "price_gbp": price_text,
                    "availability": clean_text(availability_element),
                    "rating": rating_map.get(rating, ""),
                    "product_url": product_url,
                    **detail,
                })
                print(f"  Collected: {rows[-1]['title']}")
                time.sleep(0.2)  # polite pause between detail-page requests

            next_link = soup.select_one("li.next a")
            current_url = urljoin(current_url, next_link.get("href")) if next_link else None
            page_number += 1
            time.sleep(0.5)  # polite pause between catalogue pages

    with open(OUTPUT_FILE, "w", newline="", encoding="utf-8-sig") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)

    print("\nScraping complete.")
    print(f"Unique books collected: {len(rows)}")
    print(f"Dataset saved to: {OUTPUT_FILE}")
    if rows:
        prices = [float(row["price_gbp"]) for row in rows if row["price_gbp"]]
        if prices:
            print(f"Minimum price: £{min(prices):.2f}")
            print(f"Maximum price: £{max(prices):.2f}")
            print(f"Average price: £{sum(prices) / len(prices):.2f}")

if __name__ == "__main__":
    scrape_catalogue()
